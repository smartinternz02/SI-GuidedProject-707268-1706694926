<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_We cannot find an account with that em_0dde72</name>
   <tag></tag>
   <elementGuidId>994bcd4d-aa53-485d-a9f8-a9ee33ba25d7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.a-list-item</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='auth-error-message-box']/div/div/ul/li/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>b37b0a30-de36-4e5a-a435-5ebadd72e6aa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-list-item</value>
      <webElementGuid>6fdbfbb6-09c4-41ed-a5a5-853313be2a0d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            We cannot find an account with that email address
          </value>
      <webElementGuid>67e98739-b9b6-42ab-9db1-b4ce0ae359dd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;auth-error-message-box&quot;)/div[@class=&quot;a-box-inner a-alert-container&quot;]/div[@class=&quot;a-alert-content&quot;]/ul[@class=&quot;a-unordered-list a-nostyle a-vertical a-spacing-none&quot;]/li[1]/span[@class=&quot;a-list-item&quot;]</value>
      <webElementGuid>6fee760a-3c24-48ba-af88-b15b536b671e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='auth-error-message-box']/div/div/ul/li/span</value>
      <webElementGuid>33c9e21d-99cb-499a-97e3-6cbd4e09477c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span</value>
      <webElementGuid>59a781c8-e231-4c1e-a833-c4fd811f8d13</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
            We cannot find an account with that email address
          ' or . = '
            We cannot find an account with that email address
          ')]</value>
      <webElementGuid>d59dcdc9-99f6-4caf-98f8-acd6486b21b7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
