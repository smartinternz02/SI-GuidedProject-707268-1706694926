<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h3_Popular in Books</name>
   <tag></tag>
   <elementGuidId>b6932e86-7316-4423-8e08-f4053da2b63e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h3</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='a-page']/div/div[2]/div[2]/div/div/div/h3</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h3</value>
      <webElementGuid>d41ad608-ce6d-43e9-973e-0b624e78e473</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Popular in Books</value>
      <webElementGuid>544b73e1-677c-45d3-865f-2fcd0fa8e464</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;a-page&quot;)/div[@class=&quot;a-container octopus-page-style&quot;]/div[@class=&quot;a-row apb-browse-two-col-center-pad&quot;]/div[@class=&quot;a-column a-span12 apb-browse-left-nav apb-browse-col-pad-right&quot;]/div[@class=&quot;apb-default-slot apb-default-merchandised-search-leftnav&quot;]/div[@class=&quot;celwidget pf_rd_p-5b0be665-5280-4837-85ef-e43b8114e0dc pf_rd_r-Y55YSV18TF8FFS95GG4W&quot;]/div[@class=&quot;left_nav browseBox&quot;]/h3[1]</value>
      <webElementGuid>b5a95bca-e315-4887-95a3-8f0fe9e0526a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='a-page']/div/div[2]/div[2]/div/div/div/h3</value>
      <webElementGuid>7b66f6cb-4fe1-4d3d-bb3e-5da84af784e6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Your Company Bookshelf'])[1]/following::h3[1]</value>
      <webElementGuid>33c4cb48-a6c5-4086-bb4c-3fca66b46c1d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Best Books of 2023'])[1]/following::h3[1]</value>
      <webElementGuid>d12eb09d-86c5-4226-9ab0-f845bedb2d94</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='New Year New Books'])[1]/preceding::h3[1]</value>
      <webElementGuid>3fb03bb2-3360-4970-88b1-b58b1c19e713</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Read with Pride'])[1]/preceding::h3[1]</value>
      <webElementGuid>0688888c-4343-40d4-8ace-48dac930eb63</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Popular in Books']/parent::*</value>
      <webElementGuid>818396f8-4ed3-488c-8c56-1fd95623f080</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h3</value>
      <webElementGuid>c5458f0c-0ffe-4d1f-adb2-cacd2a10f79b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h3[(text() = 'Popular in Books' or . = 'Popular in Books')]</value>
      <webElementGuid>e4793b2d-ffce-4bbc-8511-6a2797e18ca4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
