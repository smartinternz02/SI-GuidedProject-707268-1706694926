<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_VerifyEmail_AfterNewReg</name>
   <tag></tag>
   <elementGuidId>2e742d75-5ac4-40b3-8a58-2bab83f664a9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='cvf-page-content']/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.a-box-inner.a-padding-extra-large</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>6a94acf6-aaad-46b1-a8bb-dd370b0f5c48</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-box-inner a-padding-extra-large</value>
      <webElementGuid>f3dc775d-5eb0-4ae6-94ac-0449edf58ffc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

  #cvf-input-code-container {
    flex: 1;
  }









Verify email address

{&quot;isClientDrivenOtpSendingEnabled&quot;:false,&quot;arbParam&quot;:&quot;0907751b-883d-48c4-adca-5e8712028351&quot;}

      To verify your email, we've sent a One Time Password (OTP) to emailhai@emailhai.com 
(Change)


Enter OTP        
        





Please check your code and try again.
Please enter the verification code.

  
    






  P.when(&quot;A&quot;, &quot;codeResendTimer&quot;, &quot;ready&quot;).execute(function(A, codeResendTimer) {
    A.$(document).ready(function() {
      var timer = codeResendTimer.createTimer(0, 'A message with a One Time Password (OTP) has been sent to', &quot;You can now request a new code if needed.&quot;, &quot;timer&quot;, &quot;timer&quot;, false);
    });
  });


Verify


        Resend OTP


      Resend OTP










Verification required
It looks like you've requested a new OTP recently. Please wait one minute before getting a new OTP. OTPs you've already received won't work, so be sure to give the new OTP a moment to arrive.
You can now request a new code if needed.
Get new OTP



  P.when('A', 'ready').execute(function(A) {
    var $ = A.$;

    A.declarative('cvf-input-code-handler', 'keyup', function(event) {
      var VALID_DIGIT_REGEX = /^\d{6}$/;
      var $target = event.$target;

      if (VALID_DIGIT_REGEX.test($target.val())) {
        $(&quot;#verification-code-form&quot;).submit();
      }
    });

    $('.cvf-widget-link-resend').click(function() {
      $('.cvf-widget-form-resend').submit();
    });
  });

</value>
      <webElementGuid>d702c829-5b58-45f8-bd79-3b6d625fe73f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;cvf-page-content&quot;)/div[@class=&quot;a-box&quot;]/div[@class=&quot;a-box-inner a-padding-extra-large&quot;]</value>
      <webElementGuid>c437b12a-9177-426a-a24b-976712ab09ae</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='cvf-page-content']/div/div</value>
      <webElementGuid>0dd047d4-0a4c-4fad-ba1a-215f31ab98b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div/div</value>
      <webElementGuid>1b2cd6a0-4e54-4a4a-a991-8eb520be9dc8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = concat(&quot;

  #cvf-input-code-container {
    flex: 1;
  }









Verify email address

{&quot;isClientDrivenOtpSendingEnabled&quot;:false,&quot;arbParam&quot;:&quot;0907751b-883d-48c4-adca-5e8712028351&quot;}

      To verify your email, we&quot; , &quot;'&quot; , &quot;ve sent a One Time Password (OTP) to emailhai@emailhai.com 
(Change)


Enter OTP        
        





Please check your code and try again.
Please enter the verification code.

  
    






  P.when(&quot;A&quot;, &quot;codeResendTimer&quot;, &quot;ready&quot;).execute(function(A, codeResendTimer) {
    A.$(document).ready(function() {
      var timer = codeResendTimer.createTimer(0, &quot; , &quot;'&quot; , &quot;A message with a One Time Password (OTP) has been sent to&quot; , &quot;'&quot; , &quot;, &quot;You can now request a new code if needed.&quot;, &quot;timer&quot;, &quot;timer&quot;, false);
    });
  });


Verify


        Resend OTP


      Resend OTP










Verification required
It looks like you&quot; , &quot;'&quot; , &quot;ve requested a new OTP recently. Please wait one minute before getting a new OTP. OTPs you&quot; , &quot;'&quot; , &quot;ve already received won&quot; , &quot;'&quot; , &quot;t work, so be sure to give the new OTP a moment to arrive.
You can now request a new code if needed.
Get new OTP



  P.when(&quot; , &quot;'&quot; , &quot;A&quot; , &quot;'&quot; , &quot;, &quot; , &quot;'&quot; , &quot;ready&quot; , &quot;'&quot; , &quot;).execute(function(A) {
    var $ = A.$;

    A.declarative(&quot; , &quot;'&quot; , &quot;cvf-input-code-handler&quot; , &quot;'&quot; , &quot;, &quot; , &quot;'&quot; , &quot;keyup&quot; , &quot;'&quot; , &quot;, function(event) {
      var VALID_DIGIT_REGEX = /^\d{6}$/;
      var $target = event.$target;

      if (VALID_DIGIT_REGEX.test($target.val())) {
        $(&quot;#verification-code-form&quot;).submit();
      }
    });

    $(&quot; , &quot;'&quot; , &quot;.cvf-widget-link-resend&quot; , &quot;'&quot; , &quot;).click(function() {
      $(&quot; , &quot;'&quot; , &quot;.cvf-widget-form-resend&quot; , &quot;'&quot; , &quot;).submit();
    });
  });

&quot;) or . = concat(&quot;

  #cvf-input-code-container {
    flex: 1;
  }









Verify email address

{&quot;isClientDrivenOtpSendingEnabled&quot;:false,&quot;arbParam&quot;:&quot;0907751b-883d-48c4-adca-5e8712028351&quot;}

      To verify your email, we&quot; , &quot;'&quot; , &quot;ve sent a One Time Password (OTP) to emailhai@emailhai.com 
(Change)


Enter OTP        
        





Please check your code and try again.
Please enter the verification code.

  
    






  P.when(&quot;A&quot;, &quot;codeResendTimer&quot;, &quot;ready&quot;).execute(function(A, codeResendTimer) {
    A.$(document).ready(function() {
      var timer = codeResendTimer.createTimer(0, &quot; , &quot;'&quot; , &quot;A message with a One Time Password (OTP) has been sent to&quot; , &quot;'&quot; , &quot;, &quot;You can now request a new code if needed.&quot;, &quot;timer&quot;, &quot;timer&quot;, false);
    });
  });


Verify


        Resend OTP


      Resend OTP










Verification required
It looks like you&quot; , &quot;'&quot; , &quot;ve requested a new OTP recently. Please wait one minute before getting a new OTP. OTPs you&quot; , &quot;'&quot; , &quot;ve already received won&quot; , &quot;'&quot; , &quot;t work, so be sure to give the new OTP a moment to arrive.
You can now request a new code if needed.
Get new OTP



  P.when(&quot; , &quot;'&quot; , &quot;A&quot; , &quot;'&quot; , &quot;, &quot; , &quot;'&quot; , &quot;ready&quot; , &quot;'&quot; , &quot;).execute(function(A) {
    var $ = A.$;

    A.declarative(&quot; , &quot;'&quot; , &quot;cvf-input-code-handler&quot; , &quot;'&quot; , &quot;, &quot; , &quot;'&quot; , &quot;keyup&quot; , &quot;'&quot; , &quot;, function(event) {
      var VALID_DIGIT_REGEX = /^\d{6}$/;
      var $target = event.$target;

      if (VALID_DIGIT_REGEX.test($target.val())) {
        $(&quot;#verification-code-form&quot;).submit();
      }
    });

    $(&quot; , &quot;'&quot; , &quot;.cvf-widget-link-resend&quot; , &quot;'&quot; , &quot;).click(function() {
      $(&quot; , &quot;'&quot; , &quot;.cvf-widget-form-resend&quot; , &quot;'&quot; , &quot;).submit();
    });
  });

&quot;))]</value>
      <webElementGuid>7caf213f-3f21-4e2b-b1ba-fce6f56d51fd</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
