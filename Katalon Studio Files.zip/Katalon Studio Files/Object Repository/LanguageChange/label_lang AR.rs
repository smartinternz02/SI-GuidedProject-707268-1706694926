<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_lang AR</name>
   <tag></tag>
   <elementGuidId>d9a5444b-f6f7-4812-a868-b95bf43613da</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='icp-language-settings']/div[4]/div/label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>f93f0433-9f63-4f70-bf43-b7fb8b9b46df</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
        العربية -
        AR

        
            
                    
            

            
                
                    - الترجمة
                
            
        
    
</value>
      <webElementGuid>8b6d527e-0313-4ce8-a516-6bcd51a7899e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;icp-language-settings&quot;)/div[@class=&quot;a-row a-spacing-mini&quot;]/div[@class=&quot;a-radio a-radio-fancy&quot;]/label[1]</value>
      <webElementGuid>3da03b9a-4433-4220-97fb-2294f004fcf6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='icp-language-settings']/div[4]/div/label</value>
      <webElementGuid>3492eaa7-6212-42ad-8a89-9d2867950b7d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='- Traducción'])[1]/following::label[1]</value>
      <webElementGuid>389a67d0-f7b6-43de-babf-5e8fcd3a3f21</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ES'])[1]/following::label[1]</value>
      <webElementGuid>2d01c0e1-762f-4769-9198-243fd6c4683a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/label</value>
      <webElementGuid>c9f68503-6c06-4d4b-8458-722baa5ad70e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = '
    
        العربية -
        AR

        
            
                    
            

            
                
                    - الترجمة
                
            
        
    
' or . = '
    
        العربية -
        AR

        
            
                    
            

            
                
                    - الترجمة
                
            
        
    
')]</value>
      <webElementGuid>5972a2d8-69e8-4d3b-ac9f-0b420997123d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
