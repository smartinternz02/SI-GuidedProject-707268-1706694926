<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_lang ES</name>
   <tag></tag>
   <elementGuidId>5e1753b6-5668-4be9-920d-994de5a04336</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='icp-language-settings']/div[3]/div/label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>ed36a5e3-53e2-4482-897e-4da23ecf65ca</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
        español -
        ES

        
            
                    
            

            
                
                    - Traducción
                
            
        
    
</value>
      <webElementGuid>a36671a0-af4a-4e32-bf12-c6650341815f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;icp-language-settings&quot;)/div[@class=&quot;a-row a-spacing-mini&quot;]/div[@class=&quot;a-radio a-radio-fancy&quot;]/label[1]</value>
      <webElementGuid>5280de1f-7e2a-4ddc-8698-903f58961ed3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='icp-language-settings']/div[3]/div/label</value>
      <webElementGuid>ebaa505c-a1bb-46af-9928-e38cc335978d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='EN'])[2]/following::label[1]</value>
      <webElementGuid>08b951f7-0bcf-41ab-803a-b9bda579e388</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/label</value>
      <webElementGuid>913d4df4-7592-4c7d-9aae-726bc2272a28</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = '
    
        español -
        ES

        
            
                    
            

            
                
                    - Traducción
                
            
        
    
' or . = '
    
        español -
        ES

        
            
                    
            

            
                
                    - Traducción
                
            
        
    
')]</value>
      <webElementGuid>cd35fb0b-b038-4c4f-bcb3-f8a1409e9266</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
