<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_lang HE</name>
   <tag></tag>
   <elementGuidId>cfee84a6-2da6-47f3-8c78-7f83c98408ac</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='icp-language-settings']/div[6]/div/label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>28880290-2a3a-4ca5-8ebe-e0f81b6c3c3b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
        עברית -
        HE

        
            
                    
            

            
                
                    - תרגום
                
            
        
    
</value>
      <webElementGuid>ecce88f9-869a-46e0-8c28-fbde0c3b3bfb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;icp-language-settings&quot;)/div[@class=&quot;a-row a-spacing-mini&quot;]/div[@class=&quot;a-radio a-radio-fancy&quot;]/label[1]</value>
      <webElementGuid>939f40c5-f201-42e7-84d1-d6aa5e7d0b31</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='icp-language-settings']/div[6]/div/label</value>
      <webElementGuid>db08587d-5422-49ce-9e97-e4247b63505c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='- Übersetzung'])[1]/following::label[1]</value>
      <webElementGuid>e44bb67c-fe15-4d8f-ba71-617d3d3a32ab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='DE'])[1]/following::label[1]</value>
      <webElementGuid>6d1660bd-7cb6-4d4c-9b98-81f4626af8d3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[6]/div/label</value>
      <webElementGuid>432fa6f5-f61b-4fd8-9785-29132f52b4dd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = '
    
        עברית -
        HE

        
            
                    
            

            
                
                    - תרגום
                
            
        
    
' or . = '
    
        עברית -
        HE

        
            
                    
            

            
                
                    - תרגום
                
            
        
    
')]</value>
      <webElementGuid>93be1c08-6607-4d53-b2bd-913594520a28</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
