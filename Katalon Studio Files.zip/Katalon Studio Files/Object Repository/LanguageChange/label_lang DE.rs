<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_lang DE</name>
   <tag></tag>
   <elementGuidId>326a7925-5286-4085-ac07-cf9214004692</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='icp-language-settings']/div[5]/div/label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>62dafd49-2b10-4a9a-b581-5b6448605176</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
        Deutsch -
        DE

        
            
                    
            

            
                
                    - Übersetzung
                
            
        
    
</value>
      <webElementGuid>b321d7dc-595a-43cb-b0fc-6c6bcc2848d7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;icp-language-settings&quot;)/div[@class=&quot;a-row a-spacing-mini&quot;]/div[@class=&quot;a-radio a-radio-fancy&quot;]/label[1]</value>
      <webElementGuid>52216a2d-feab-4952-ab96-c4e80dd3c043</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='icp-language-settings']/div[5]/div/label</value>
      <webElementGuid>0a7605ba-cbbe-4dc1-8091-88e01d28c2bd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='- الترجمة'])[1]/following::label[1]</value>
      <webElementGuid>08e4ca61-b5c8-4439-b270-544928518924</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AR'])[1]/following::label[1]</value>
      <webElementGuid>857f808d-f556-42ad-a77e-19acae4b90ad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div/label</value>
      <webElementGuid>77e3a04c-0bf5-49b4-8499-bd96aa47599a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = '
    
        Deutsch -
        DE

        
            
                    
            

            
                
                    - Übersetzung
                
            
        
    
' or . = '
    
        Deutsch -
        DE

        
            
                    
            

            
                
                    - Übersetzung
                
            
        
    
')]</value>
      <webElementGuid>6b5899d8-9387-4f83-baa6-8e9f5a4ea797</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
