<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_lang KO</name>
   <tag></tag>
   <elementGuidId>8ecd918b-7d24-4446-bdff-19d1cfd88dfa</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='icp-language-settings']/div[7]/div/label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>404a3477-bc9d-4a3d-90d1-e45f16b6e57f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
        한국어 -
        KO

        
            
                    
            

            
                
                    - 번역
                
            
        
    
</value>
      <webElementGuid>839bfe08-adf8-4f2a-a4f7-b43fd80f4d40</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;icp-language-settings&quot;)/div[@class=&quot;a-row a-spacing-mini&quot;]/div[@class=&quot;a-radio a-radio-fancy&quot;]/label[1]</value>
      <webElementGuid>ba5d2e56-845e-49b0-bbe3-7c7f17f5e527</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='icp-language-settings']/div[7]/div/label</value>
      <webElementGuid>9cb9794c-c964-4e47-837d-5baa7093830b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='- תרגום'])[1]/following::label[1]</value>
      <webElementGuid>05d090e5-76f0-4867-9e8a-ee36c023ca7a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='HE'])[1]/following::label[1]</value>
      <webElementGuid>84c97f1e-afb3-4b90-9101-72626ace2bb1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div/label</value>
      <webElementGuid>887218f2-6ca9-409b-be51-f29366db4382</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = '
    
        한국어 -
        KO

        
            
                    
            

            
                
                    - 번역
                
            
        
    
' or . = '
    
        한국어 -
        KO

        
            
                    
            

            
                
                    - 번역
                
            
        
    
')]</value>
      <webElementGuid>1277eb64-7477-4099-9259-a6060e39455e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
