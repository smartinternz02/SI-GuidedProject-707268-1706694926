<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_lang PT</name>
   <tag></tag>
   <elementGuidId>91069d36-99fa-49ad-95f1-5514509448c2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='icp-language-settings']/div[8]/div/label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>bcc766ca-d86b-4593-9060-0b4f37e25065</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
        português -
        PT

        
            
                    
            

            
                
                    - Tradução
                
            
        
    
</value>
      <webElementGuid>6660291c-f616-414d-b5f4-6f449a88483a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;icp-language-settings&quot;)/div[@class=&quot;a-row a-spacing-mini&quot;]/div[@class=&quot;a-radio a-radio-fancy&quot;]/label[1]</value>
      <webElementGuid>29595e00-eda6-4dd1-9343-ff7601296253</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='icp-language-settings']/div[8]/div/label</value>
      <webElementGuid>adf7309a-a021-4595-9a70-f1bdcce507e2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='- 번역'])[1]/following::label[1]</value>
      <webElementGuid>72c74f9b-6825-4db1-b0e3-db876411b371</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='KO'])[1]/following::label[1]</value>
      <webElementGuid>83b59d7e-98b4-4411-8e99-ab8f177e5863</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[8]/div/label</value>
      <webElementGuid>64733a80-b9e7-4844-a07b-31bc15094bb5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = '
    
        português -
        PT

        
            
                    
            

            
                
                    - Tradução
                
            
        
    
' or . = '
    
        português -
        PT

        
            
                    
            

            
                
                    - Tradução
                
            
        
    
')]</value>
      <webElementGuid>85934fba-22b5-46c7-b98a-8082048d667e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
