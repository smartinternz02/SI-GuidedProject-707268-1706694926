<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_lang ZH</name>
   <tag></tag>
   <elementGuidId>13948fb7-a9a3-405d-ac41-6d753210f8a7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='icp-language-settings']/div[10]/div/label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>4ba5fd29-a5c2-4b50-b47a-19cafcdc7050</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
        中文 (繁體) -
        ZH

        
            
                    
            

            
                
                    - 翻譯
                
            
        
    
</value>
      <webElementGuid>ddd84087-c69e-47b6-aa25-fe5a830ae330</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;icp-language-settings&quot;)/div[@class=&quot;a-row a-spacing-mini&quot;]/div[@class=&quot;a-radio a-radio-fancy&quot;]/label[1]</value>
      <webElementGuid>9fd4bbb9-b4f6-4828-9e29-be442ada0ac3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='icp-language-settings']/div[10]/div/label</value>
      <webElementGuid>8247aecf-15ae-4743-8ac9-c07299ae85a3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='- 翻译'])[1]/following::label[1]</value>
      <webElementGuid>a44ec912-8962-47b3-b12a-b045450e79c4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ZH'])[1]/following::label[1]</value>
      <webElementGuid>904b41a3-f96e-46d0-89fd-6b15e075a2cc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[10]/div/label</value>
      <webElementGuid>e84a656d-65b4-4a1e-88bf-35221f2d779b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = '
    
        中文 (繁體) -
        ZH

        
            
                    
            

            
                
                    - 翻譯
                
            
        
    
' or . = '
    
        中文 (繁體) -
        ZH

        
            
                    
            

            
                
                    - 翻譯
                
            
        
    
')]</value>
      <webElementGuid>ecf1cc50-c36a-4593-bdf7-d97ba7009309</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
