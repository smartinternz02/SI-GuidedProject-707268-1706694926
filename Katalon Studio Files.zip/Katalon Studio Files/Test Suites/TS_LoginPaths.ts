<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>Testings all Login Paths such as:&#xd;
1)Valid Login&#xd;
2) Invalid Login&#xd;
3) New User Login</description>
   <name>TS_LoginPaths</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>e7dae94b-1b05-43ce-9425-e590bfb80751</testSuiteGuid>
   <testCaseLink>
      <guid>b7c474c7-5bb6-428b-883e-7132eb9c9243</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <iterationNameVariable>
         <defaultValue>''</defaultValue>
         <description></description>
         <id>1b2bb997-7d2f-423f-8079-b02a5c5f062f</id>
         <masked>false</masked>
         <name>password</name>
      </iterationNameVariable>
      <testCaseId>Test Cases/Data Driven Testing/TC001_New User Login</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>599ffd2f-3d10-4de6-b5d8-6959b1ae1f52</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/ExecelDataForNewUser</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>599ffd2f-3d10-4de6-b5d8-6959b1ae1f52</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Name</value>
         <variableId>3acd4c73-1fff-4256-820e-5947d9150037</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>599ffd2f-3d10-4de6-b5d8-6959b1ae1f52</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>email </value>
         <variableId>2691d95b-6381-499f-8644-88e602b06709</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>599ffd2f-3d10-4de6-b5d8-6959b1ae1f52</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>password </value>
         <variableId>1b2bb997-7d2f-423f-8079-b02a5c5f062f</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>9b7d2643-8d65-487f-a84b-cde73b6cd1b0</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Data Driven Testing/TC002_Valid Login</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
   <testCaseLink>
      <guid>77d755f6-0c11-4db7-a65e-84267070db0d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Data Driven Testing/TC003_Invalid Login</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
</TestSuiteEntity>
